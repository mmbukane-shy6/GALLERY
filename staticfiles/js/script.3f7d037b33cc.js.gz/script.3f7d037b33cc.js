// copyaction = ()=>{
//   document.getElementById("link").select();
//   document.execCommand("Copy");
//   }

// function copyaction(){
//   var copyLink=document.getElementById("link");
//   copyLink.querySelector();
//   document.execCommand("copy")
// }